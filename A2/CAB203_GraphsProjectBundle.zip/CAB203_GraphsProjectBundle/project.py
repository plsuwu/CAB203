import graphs
import digraphs
import csv

def gamesOK(games):
   pass

def referees(games, refereecsvfilename):
   pass

def gameGroups(assignedReferees):
   pass

def gameSchedule(assignedReferees, gameGroups):
   pass

def scores(p, s, c, games):
   pass